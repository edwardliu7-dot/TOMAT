import { X, Star, CheckCircle2, Circle, Mic, PenLine, ListChecks } from "lucide-react";

const categories = [
  {
    id: "devout", label: "Ketaqwaan",
    color: "from-emerald-500 to-teal-500", lightBg: "bg-emerald-50", border: "border-emerald-200",
    text: "text-emerald-700", check: "text-emerald-500",
    done: 6, total: 7,
  },
  {
    id: "resilience", label: "Ketangguhan",
    color: "from-amber-500 to-orange-400", lightBg: "bg-amber-50", border: "border-amber-200",
    text: "text-amber-700", check: "text-amber-500",
    done: 2, total: 3,
  },
  {
    id: "resourceful", label: "Kecakapan",
    color: "from-blue-500 to-sky-400", lightBg: "bg-blue-50", border: "border-blue-200",
    text: "text-blue-700", check: "text-blue-500",
    done: 3, total: 3,
  },
  {
    id: "reflective", label: "Reflektif",
    color: "from-violet-500 to-purple-400", lightBg: "bg-violet-50", border: "border-violet-200",
    text: "text-violet-700", check: "text-violet-500",
    done: 1, total: 2,
  },
  {
    id: "reciprocity", label: "Kepedulian",
    color: "from-rose-500 to-pink-400", lightBg: "bg-rose-50", border: "border-rose-200",
    text: "text-rose-700", check: "text-rose-500",
    done: 1, total: 3,
  },
];

const totalDone = categories.reduce((s, c) => s + c.done, 0);
const totalAct = categories.reduce((s, c) => s + c.total, 0);
const pct = Math.round((totalDone / totalAct) * 100);
const stars = Math.ceil(pct / 20);

export function Presentasi() {
  return (
    <div className="min-h-screen bg-[#f5f7f2] font-sans text-[#17352d] flex flex-col">
      {/* Top bar */}
      <div className="flex items-center justify-between px-8 py-4 bg-white border-b border-gray-100 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 flex items-center justify-center text-white font-extrabold text-sm">B</div>
          <div>
            <div className="font-bold text-base text-[#17352d]">BLP Harian</div>
            <div className="text-xs text-gray-500">Laporan Aktivitas Harian</div>
          </div>
        </div>
        <div className="text-center">
          <div className="text-sm font-bold text-gray-700">Kamis, 1 Agustus 2026</div>
          <div className="text-xs text-gray-400">Semester Ganjil 2026/2027</div>
        </div>
        <button className="flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-600 px-4 py-2 rounded-xl text-sm font-medium transition">
          <X className="w-4 h-4" /> Tutup Presentasi
        </button>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col items-center justify-start px-8 py-6 gap-6">
        {/* Student hero */}
        <div className="w-full max-w-3xl bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-700 rounded-3xl p-8 text-white shadow-xl flex items-center gap-8">
          <div className="w-24 h-24 rounded-3xl bg-white/20 border-2 border-white/30 flex items-center justify-center text-4xl font-black">AR</div>
          <div className="flex-1">
            <div className="text-3xl font-black tracking-tight leading-tight">Aisyah Rahmawati</div>
            <div className="text-emerald-200 text-sm mt-1">Kelas 7A · NIS: 2024001 · SMP TISA Islamic School</div>
            <div className="flex gap-1 mt-3">
              {[1,2,3,4,5].map(s => (
                <Star key={s} className={`w-6 h-6 ${s <= stars ? "text-amber-300 fill-amber-300" : "text-white/30"}`} />
              ))}
            </div>
          </div>
          <div className="text-center bg-white/15 rounded-2xl px-8 py-4 border border-white/20">
            <div className="text-6xl font-black leading-none">{pct}<span className="text-3xl">%</span></div>
            <div className="text-emerald-200 text-sm mt-2 font-medium">Pencapaian Hari Ini</div>
            <div className="text-white/80 text-xs mt-1">{totalDone} dari {totalAct} aktivitas</div>
          </div>
        </div>

        {/* Category grid */}
        <div className="w-full max-w-3xl grid grid-cols-5 gap-3">
          {categories.map(cat => {
            const catPct = Math.round((cat.done / cat.total) * 100);
            return (
              <div key={cat.id} className={`bg-white rounded-2xl border ${cat.border} shadow-sm p-4 flex flex-col items-center gap-2`}>
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${cat.color} flex items-center justify-center`}>
                  <span className="text-white text-xl font-black">{catPct}<span className="text-xs">%</span></span>
                </div>
                <div className={`text-xs font-bold text-center ${cat.text}`}>{cat.label}</div>
                <div className="text-xs text-gray-500">{cat.done}/{cat.total}</div>
                <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className={`h-full bg-gradient-to-r ${cat.color} rounded-full`} style={{ width: `${catPct}%` }} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Activity summary */}
        <div className="w-full max-w-3xl bg-white rounded-2xl border border-emerald-100 shadow-sm p-5">
          <h3 className="font-bold text-[#17352d] mb-4 text-sm">Ringkasan Aktivitas</h3>
          <div className="grid grid-cols-5 gap-2">
            {categories.map(cat => (
              <div key={cat.id} className={`rounded-xl p-3 ${cat.lightBg} border ${cat.border}`}>
                <div className={`text-xs font-bold ${cat.text} mb-2`}>{cat.label}</div>
                <div className="space-y-1">
                  {Array.from({ length: cat.total }).map((_, i) => (
                    <div key={i} className="flex items-center gap-1.5">
                      {i < cat.done
                        ? <CheckCircle2 className={`w-3.5 h-3.5 ${cat.check}`} />
                        : <Circle className="w-3.5 h-3.5 text-gray-300" />}
                      <div className={`h-1.5 flex-1 rounded-full ${i < cat.done ? `bg-gradient-to-r ${cat.color}` : "bg-gray-200"}`} />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-gray-400">
          BLP Harian · SMP TISA Islamic School · Building Learning Power 2026
        </div>
      </div>
    </div>
  );
}
