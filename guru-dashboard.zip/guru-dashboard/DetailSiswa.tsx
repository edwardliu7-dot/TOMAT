import {
  ChevronLeft, ChevronRight, Presentation, CheckCircle2, Circle,
  Mic, PenLine, ListChecks, BookOpen, LogOut, Users, BarChart3,
  Heart, ArrowLeft, Star, Eye,
} from "lucide-react";

const categories = [
  {
    id: "devout", label: "Ketaqwaan", color: "emerald",
    bar: "bg-emerald-500", lightBg: "bg-emerald-50", border: "border-emerald-200", text: "text-emerald-700",
    activities: [
      { label: "Shalat Subuh Berjamaah", done: true, type: "check" },
      { label: "Tilawah Al-Qur'an (1 Halaman)", done: true, type: "audio", note: "Al-Baqarah 1–5" },
      { label: "Shalat Dhuha", done: true, type: "check" },
      { label: "Dzikir Pagi", done: false, type: "check" },
      { label: "Shalat Dzuhur Berjamaah", done: true, type: "check" },
      { label: "Shalat Ashar Berjamaah", done: true, type: "check" },
      { label: "Perlengkapan Sekolah", done: true, type: "checklist" },
    ],
  },
  {
    id: "resilience", label: "Ketangguhan", color: "amber",
    bar: "bg-amber-500", lightBg: "bg-amber-50", border: "border-amber-200", text: "text-amber-700",
    activities: [
      { label: "Olahraga Pagi (30 menit)", done: true, type: "check" },
      { label: "Rapi Kamar Tidur", done: true, type: "check" },
      { label: "Makan Tepat Waktu", done: false, type: "check" },
    ],
  },
  {
    id: "resourceful", label: "Kecakapan", color: "blue",
    bar: "bg-blue-500", lightBg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700",
    activities: [
      { label: "Membaca Buku (15 menit)", done: true, type: "check" },
      { label: "Rangkuman Belajar Hari Ini", done: true, type: "text", note: "250 karakter" },
      { label: "Belajar Mandiri", done: true, type: "check" },
    ],
  },
  {
    id: "reflective", label: "Reflektif", color: "violet",
    bar: "bg-violet-500", lightBg: "bg-violet-50", border: "border-violet-200", text: "text-violet-700",
    activities: [
      { label: "Jurnal Syukur (3 hal)", done: true, type: "text", note: "180 karakter" },
      { label: "Evaluasi Diri Sebelum Tidur", done: false, type: "text" },
    ],
  },
  {
    id: "reciprocity", label: "Kepedulian", color: "rose",
    bar: "bg-rose-500", lightBg: "bg-rose-50", border: "border-rose-200", text: "text-rose-700",
    activities: [
      { label: "Membantu Orang Tua", done: true, type: "check" },
      { label: "Berbuat Baik kepada Teman", done: false, type: "check" },
      { label: "Laporan Kegiatan", done: false, type: "text" },
    ],
  },
];

const totalAct = categories.flatMap(c => c.activities).length;
const doneAct = categories.flatMap(c => c.activities).filter(a => a.done).length;
const pct = Math.round((doneAct / totalAct) * 100);

function TypeIcon({ type }: { type: string }) {
  if (type === "audio") return <Mic className="w-3.5 h-3.5 text-gray-400" />;
  if (type === "text") return <PenLine className="w-3.5 h-3.5 text-gray-400" />;
  if (type === "checklist") return <ListChecks className="w-3.5 h-3.5 text-gray-400" />;
  return null;
}

export function DetailSiswa() {
  return (
    <div className="min-h-screen bg-[#f5f7f2] font-sans text-[#17352d]">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-600 text-white shadow-lg">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center font-extrabold text-sm">B</div>
            <div>
              <div className="font-bold text-lg leading-tight">BLP Harian</div>
              <div className="text-xs text-emerald-100">SMP TISA Islamic School</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-sm font-semibold">Ustazah Sari Dewi</div>
              <div className="text-xs text-emerald-100">Wali Kelas 7A</div>
            </div>
            <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center font-bold text-sm">SD</div>
            <button className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg text-sm">
              <LogOut className="w-4 h-4" /> Keluar
            </button>
          </div>
        </div>
        <div className="max-w-4xl mx-auto px-6 flex gap-1 pb-0">
          {[{ label: "Daftar Siswa", icon: Users, active: true }, { label: "Rekap Nilai", icon: BarChart3 }, { label: "Haid Siswi", icon: Heart }].map(tab => (
            <button key={tab.label} className={`flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-t-xl transition ${tab.active ? "bg-[#f5f7f2] text-emerald-700 shadow-sm" : "text-white/80 hover:bg-white/10"}`}>
              <tab.icon className="w-4 h-4" /> {tab.label}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-6 space-y-5">
        {/* Back + Presentation buttons */}
        <div className="flex items-center justify-between">
          <button className="flex items-center gap-2 text-emerald-700 font-semibold text-sm hover:bg-emerald-50 px-3 py-2 rounded-xl transition">
            <ArrowLeft className="w-4 h-4" /> Kembali ke Daftar
          </button>
          <button className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold shadow transition">
            <Presentation className="w-4 h-4" /> Mode Presentasi
          </button>
        </div>

        {/* Student identity + date */}
        <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm p-5 flex items-center gap-5">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-white text-xl font-black flex-shrink-0">AR</div>
          <div className="flex-1">
            <div className="font-bold text-xl text-[#17352d]">Aisyah Rahmawati</div>
            <div className="text-sm text-gray-500">Kelas 7A · NIS: 2024001</div>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-2">
              <button className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-700 hover:bg-emerald-100">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <div className="text-sm font-semibold text-[#17352d] text-center w-32">Kamis, 1 Agt 2026</div>
              <button className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-700 hover:bg-emerald-100">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Score hero */}
        <div className="bg-gradient-to-br from-emerald-600 to-teal-600 rounded-2xl p-5 text-white flex items-center gap-6 shadow">
          <div className="text-center">
            <div className="text-5xl font-black">{pct}<span className="text-2xl">%</span></div>
            <div className="text-emerald-100 text-xs mt-1 font-medium">Pencapaian</div>
          </div>
          <div className="w-px h-14 bg-white/20" />
          <div className="flex-1 grid grid-cols-3 gap-3 text-center">
            <div><div className="text-2xl font-black">{doneAct}</div><div className="text-emerald-200 text-xs">Selesai</div></div>
            <div><div className="text-2xl font-black">{totalAct - doneAct}</div><div className="text-emerald-200 text-xs">Belum</div></div>
            <div>
              <div className="flex justify-center gap-0.5 mb-0.5">
                {[1,2,3,4,5].map(s => <Star key={s} className={`w-4 h-4 ${s <= Math.ceil(pct/20) ? "text-amber-300 fill-amber-300" : "text-white/30"}`} />)}
              </div>
              <div className="text-emerald-200 text-xs">Rating</div>
            </div>
          </div>
        </div>

        {/* Activity categories */}
        <div className="space-y-3">
          {categories.map(cat => {
            const catDone = cat.activities.filter(a => a.done).length;
            const catTotal = cat.activities.length;
            const catPct = Math.round((catDone / catTotal) * 100);
            return (
              <div key={cat.id} className="bg-white rounded-2xl border border-emerald-100 shadow-sm overflow-hidden">
                <div className={`flex items-center justify-between px-5 py-3 ${cat.lightBg} border-b ${cat.border}`}>
                  <span className={`font-bold text-sm ${cat.text}`}>{cat.label}</span>
                  <span className={`text-xs font-semibold ${cat.text}`}>{catDone}/{catTotal} · {catPct}%</span>
                </div>
                <div className="divide-y divide-gray-50">
                  {cat.activities.map((act, i) => (
                    <div key={i} className="flex items-center gap-3 px-5 py-3">
                      {act.done
                        ? <CheckCircle2 className={`w-5 h-5 flex-shrink-0 text-${cat.color}-500`} />
                        : <Circle className="w-5 h-5 flex-shrink-0 text-gray-300" />}
                      <span className={`flex-1 text-sm ${act.done ? "text-gray-800" : "text-gray-400"}`}>{act.label}</span>
                      {act.type !== "check" && <TypeIcon type={act.type} />}
                      {act.note && <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">{act.note}</span>}
                      {act.type !== "check" && act.done && (
                        <button className="flex items-center gap-1 text-xs text-emerald-600 font-semibold hover:bg-emerald-50 px-2 py-1 rounded-lg transition">
                          <Eye className="w-3.5 h-3.5" /> Lihat
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
