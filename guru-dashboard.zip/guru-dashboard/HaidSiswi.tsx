import {
  Heart, AlertTriangle, ShieldAlert, Info, LogOut, Users, BarChart3,
  Clock, CheckCircle2, Calendar,
} from "lucide-react";

const siswi = [
  { name: "Aisyah Rahmawati",   status: "normal",   active: false, start: "5 Jun", end: "11 Jun", dur: 7, cycle: 33, warning: null },
  { name: "Citra Dewi",          status: "active",   active: true,  start: "30 Jul", end: null,   dur: 2, cycle: 31, warning: null },
  { name: "Elfira Nadia",        status: "normal",   active: false, start: "12 Jul", end: "18 Jul", dur: 7, cycle: 32, warning: null },
  { name: "Ghania Putri",        status: "warning",  active: true,  start: "18 Jul", end: null,   dur: 14, cycle: 35, warning: "Durasi melebihi 10 hari" },
  { name: "Indira Salsabila",    status: "normal",   active: false, start: "2 Jul",  end: "8 Jul", dur: 6, cycle: 29, warning: null },
  { name: "Kirana Maharani",     status: "warning",  active: false, start: "5 Jun",  end: "12 Jun", dur: 8, cycle: 24, warning: "Siklus < 27 hari" },
  { name: "Layla Azzahra",       status: "normal",   active: false, start: "20 Jun", end: "26 Jun", dur: 6, cycle: 30, warning: null },
  { name: "Maya Sari",           status: "active",   active: true,  start: "1 Agt",  end: null,   dur: 1, cycle: 30, warning: null },
];

const activeCnt = siswi.filter(s => s.active).length;
const warningCnt = siswi.filter(s => s.warning).length;
const normalCnt = siswi.filter(s => !s.warning && !s.active).length;

type SiswiStatus = "active" | "warning" | "normal";

const statusBadge: Record<SiswiStatus, string> = {
  active:  "bg-rose-100 text-rose-700 border border-rose-200",
  warning: "bg-amber-100 text-amber-700 border border-amber-200",
  normal:  "bg-emerald-100 text-emerald-700 border border-emerald-200",
};

const statusLabel: Record<SiswiStatus, string> = {
  active:  "Sedang Haid",
  warning: "Perlu Perhatian",
  normal:  "Normal",
};

export function HaidSiswi() {
  return (
    <div className="min-h-screen bg-[#f5f7f2] font-sans text-[#17352d] flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-600 text-white shadow-lg">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center font-extrabold text-sm">B</div>
            <div>
              <div className="font-bold text-lg leading-tight">BLP Harian</div>
              <div className="text-xs text-emerald-100">SMP TISA Islamic School</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-sm font-semibold">Ustazah Sari Dewi</div>
              <div className="text-xs text-emerald-100">Wali Kelas 7A</div>
            </div>
            <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center font-bold text-sm">SD</div>
            <button className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg text-sm">
              <LogOut className="w-4 h-4" /> Keluar
            </button>
          </div>
        </div>
        <div className="max-w-4xl mx-auto px-6 flex gap-1 pb-0">
          {[{ label: "Daftar Siswa", icon: Users }, { label: "Rekap Nilai", icon: BarChart3 }, { label: "Haid Siswi", icon: Heart, active: true }].map(tab => (
            <button key={tab.label} className={`flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-t-xl transition ${(tab as any).active ? "bg-[#f5f7f2] text-emerald-700 shadow-sm" : "text-white/80 hover:bg-white/10"}`}>
              <tab.icon className="w-4 h-4" /> {tab.label}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8 space-y-5 flex-1">
        {/* Summary banner */}
        {warningCnt > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-amber-800 text-sm">Perlu Perhatian</div>
              <div className="text-amber-700 text-xs mt-0.5">{warningCnt} siswi memiliki data haid yang perlu diperhatikan (durasi atau siklus tidak normal).</div>
            </div>
          </div>
        )}

        {/* Stats cards */}
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: "Sedang Haid",     val: activeCnt,  icon: Heart,        color: "text-rose-600",    bg: "bg-rose-50",    border: "border-rose-200" },
            { label: "Perlu Perhatian", val: warningCnt, icon: AlertTriangle, color: "text-amber-600",   bg: "bg-amber-50",   border: "border-amber-200" },
            { label: "Siklus Normal",   val: normalCnt,  icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-50", border: "border-emerald-200" },
          ].map(s => (
            <div key={s.label} className={`${s.bg} rounded-2xl border ${s.border} shadow-sm p-4 flex items-center gap-3`}>
              <s.icon className={`w-8 h-8 ${s.color} flex-shrink-0`} />
              <div>
                <div className={`text-3xl font-black ${s.color}`}>{s.val}</div>
                <div className="text-xs text-gray-600 font-medium mt-0.5">{s.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Title */}
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-[#17352d] flex items-center gap-2">
            <Heart className="w-5 h-5 text-rose-500" /> Data Haid Siswi — Kelas 7A
          </h3>
          <div className="text-xs text-gray-500 bg-white border border-gray-200 px-3 py-1.5 rounded-xl">
            {siswi.length} siswi terdaftar
          </div>
        </div>

        {/* Student list */}
        <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm overflow-hidden">
          <div className="divide-y divide-gray-50">
            {siswi.map((s, i) => (
              <div key={i} className={`px-5 py-4 flex items-center gap-4 ${s.status === "warning" ? "bg-amber-50/50" : ""}`}>
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-rose-400 to-pink-500 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {s.name.split(" ").map((w: string) => w[0]).slice(0, 2).join("")}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm text-[#17352d] flex items-center gap-2">
                    {s.name}
                    {s.warning && <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />}
                  </div>
                  <div className="text-xs text-gray-500 mt-0.5 flex items-center gap-3">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {s.active ? `Mulai ${s.start}` : `${s.start} – ${s.end} (${s.dur} hr)`}
                    </span>
                    {s.cycle && <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Siklus ~{s.cycle} hr</span>}
                  </div>
                  {s.warning && (
                    <div className="text-xs text-amber-700 bg-amber-100 rounded-lg px-2 py-0.5 mt-1 inline-block">{s.warning}</div>
                  )}
                </div>
                <span className={`text-xs font-semibold px-3 py-1 rounded-full flex-shrink-0 ${statusBadge[s.status as SiswiStatus]}`}>
                  {statusLabel[s.status as SiswiStatus]}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="text-xs text-gray-400 flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5" />
          Data ini dicatat oleh siswi sendiri melalui menu Pengaturan. Konsultasikan anomali ke pihak berwenang.
        </div>
      </main>
    </div>
  );
}
