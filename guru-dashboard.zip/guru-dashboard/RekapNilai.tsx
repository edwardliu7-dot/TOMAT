import {
  ChevronLeft, ChevronRight, Download, FileSpreadsheet, Settings2,
  LogOut, Users, BarChart3, Heart, TrendingUp,
} from "lucide-react";

const students = [
  { name: "Aisyah Rahmawati",  days: 27, jun: 85, jul: 88, aug: 82, avg: 85 },
  { name: "Budi Santoso",       days: 22, jun: 70, jul: 73, aug: 75, avg: 73 },
  { name: "Citra Dewi",         days: 29, jun: 93, jul: 95, aug: 94, avg: 94 },
  { name: "Dimas Prakasa",      days: 18, jun: 62, jul: 60, aug: 65, avg: 62 },
  { name: "Elfira Nadia",       days: 25, jun: 80, jul: 82, aug: 81, avg: 81 },
  { name: "Fajar Hidayat",      days: 28, jun: 88, jul: 91, aug: 90, avg: 90 },
  { name: "Ghania Putri",       days: 14, jun: 45, jul: 48, aug: 50, avg: 48 },
  { name: "Haris Maulana",      days: 24, jun: 78, jul: 80, aug: 76, avg: 78 },
  { name: "Indira Salsabila",   days: 26, jun: 82, jul: 85, aug: 83, avg: 83 },
  { name: "Joko Susilo",        days: 20, jun: 68, jul: 70, aug: 72, avg: 70 },
];

const scoreColor = (s: number) =>
  s >= 85 ? "text-emerald-600" : s >= 70 ? "text-amber-500" : "text-red-500";
const scoreBg = (s: number) =>
  s >= 85 ? "bg-emerald-50 border-emerald-200" : s >= 70 ? "bg-amber-50 border-amber-200" : "bg-red-50 border-red-200";

export function RekapNilai() {
  const avgAll = Math.round(students.reduce((s, r) => s + r.avg, 0) / students.length);
  const top = [...students].sort((a, b) => b.avg - a.avg)[0];

  return (
    <div className="min-h-screen bg-[#f5f7f2] font-sans text-[#17352d] flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-600 text-white shadow-lg">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center font-extrabold text-sm">B</div>
            <div>
              <div className="font-bold text-lg leading-tight">BLP Harian</div>
              <div className="text-xs text-emerald-100">SMP TISA Islamic School</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-sm font-semibold">Ustazah Sari Dewi</div>
              <div className="text-xs text-emerald-100">Wali Kelas 7A</div>
            </div>
            <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center font-bold text-sm">SD</div>
            <button className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg text-sm">
              <LogOut className="w-4 h-4" /> Keluar
            </button>
          </div>
        </div>
        <div className="max-w-5xl mx-auto px-6 flex gap-1 pb-0">
          {[{ label: "Daftar Siswa", icon: Users }, { label: "Rekap Nilai", icon: BarChart3, active: true }, { label: "Haid Siswi", icon: Heart }].map(tab => (
            <button key={tab.label} className={`flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-t-xl transition ${tab.active ? "bg-[#f5f7f2] text-emerald-700 shadow-sm" : "text-white/80 hover:bg-white/10"}`}>
              <tab.icon className="w-4 h-4" /> {tab.label}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8 space-y-6 flex-1">
        {/* Month nav */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button className="w-9 h-9 rounded-xl bg-white border border-emerald-200 flex items-center justify-center text-emerald-700 hover:bg-emerald-50 shadow-sm">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <h2 className="text-xl font-bold text-[#17352d]">Agustus 2026 — Kelas 7A</h2>
            <button className="w-9 h-9 rounded-xl bg-white border border-emerald-200 flex items-center justify-center text-emerald-700 hover:bg-emerald-50 shadow-sm">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 bg-white border border-emerald-200 text-emerald-700 hover:bg-emerald-50 px-4 py-2 rounded-xl text-sm font-semibold shadow-sm transition">
              <Settings2 className="w-4 h-4" /> Atur Hari Aktif BLP
            </button>
            <button className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl text-sm font-semibold shadow transition">
              <Download className="w-4 h-4" /> PDF
            </button>
            <button className="flex items-center gap-2 bg-white border border-emerald-200 text-emerald-700 hover:bg-emerald-50 px-4 py-2 rounded-xl text-sm font-semibold shadow-sm transition">
              <FileSpreadsheet className="w-4 h-4" /> Excel
            </button>
          </div>
        </div>

        {/* Summary stats */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "Rata-rata Kelas",   val: `${avgAll}%`, icon: TrendingUp, color: "text-emerald-600", bg: "bg-emerald-50" },
            { label: "Siswa Teratas",      val: top.name.split(" ")[0], icon: BarChart3, color: "text-amber-600", bg: "bg-amber-50" },
            { label: "Skor Tertinggi",     val: `${top.avg}%`, icon: BarChart3, color: "text-blue-600", bg: "bg-blue-50" },
            { label: "Total Siswa",        val: `${students.length}`, icon: Users, color: "text-violet-600", bg: "bg-violet-50" },
          ].map(s => (
            <div key={s.label} className={`${s.bg} rounded-2xl border border-white/80 shadow-sm p-4 flex items-center gap-3`}>
              <s.icon className={`w-8 h-8 ${s.color} flex-shrink-0`} />
              <div>
                <div className={`text-2xl font-black ${s.color}`}>{s.val}</div>
                <div className="text-xs text-gray-600 font-medium mt-0.5">{s.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-emerald-50 border-b border-emerald-100">
                <th className="text-left px-5 py-3 text-xs font-bold text-emerald-800 uppercase tracking-wider">Nama Siswa</th>
                <th className="text-center px-4 py-3 text-xs font-bold text-emerald-800 uppercase tracking-wider">Hari Terskor</th>
                <th className="text-center px-4 py-3 text-xs font-bold text-emerald-800 uppercase tracking-wider">Jun</th>
                <th className="text-center px-4 py-3 text-xs font-bold text-emerald-800 uppercase tracking-wider">Jul</th>
                <th className="text-center px-4 py-3 text-xs font-bold text-emerald-800 uppercase tracking-wider">Agt</th>
                <th className="text-center px-4 py-3 text-xs font-bold text-emerald-800 uppercase tracking-wider">Rata-rata</th>
                <th className="px-5 py-3 text-xs font-bold text-emerald-800 uppercase tracking-wider">Tren</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {students.map((s, i) => (
                <tr key={i} className="hover:bg-gray-50 transition">
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                        {s.name.split(" ").map((w: string) => w[0]).slice(0, 2).join("")}
                      </div>
                      <span className="font-medium text-[#17352d]">{s.name}</span>
                    </div>
                  </td>
                  <td className="text-center px-4 py-3.5 font-semibold text-gray-700">{s.days}</td>
                  {[s.jun, s.jul, s.aug].map((v, j) => (
                    <td key={j} className="text-center px-4 py-3.5">
                      <span className={`inline-block px-2 py-0.5 rounded-lg text-xs font-bold border ${scoreBg(v)} ${scoreColor(v)}`}>{v}%</span>
                    </td>
                  ))}
                  <td className="text-center px-4 py-3.5">
                    <span className={`inline-block px-3 py-1 rounded-xl text-sm font-black border ${scoreBg(s.avg)} ${scoreColor(s.avg)}`}>{s.avg}%</span>
                  </td>
                  <td className="px-5 py-3.5">
                    <div className="w-20 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${s.avg >= 85 ? "bg-emerald-500" : s.avg >= 70 ? "bg-amber-400" : "bg-red-400"}`} style={{ width: `${s.avg}%` }} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
