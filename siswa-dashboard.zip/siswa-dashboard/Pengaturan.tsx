import {
  Bell, BellOff, Download, LogOut, Settings, Calendar,
  LayoutDashboard, User, Camera, Heart, HeartOff, Clock, ChevronRight, Shield
} from "lucide-react";

const haidHistory = [
  { start: "5 Jun 2026", end: "11 Jun 2026", duration: 7, status: "Selesai" },
  { start: "8 May 2026", end: "14 May 2026", duration: 7, status: "Selesai" },
  { start: "10 Apr 2026", end: "16 Apr 2026", duration: 7, status: "Selesai" },
  { start: "12 Mar 2026", end: "18 Mar 2026", duration: 6, status: "Selesai" },
  { start: "14 Feb 2026", end: "20 Feb 2026", duration: 6, status: "Selesai" },
  { start: "17 Jan 2026", end: "23 Jan 2026", duration: 7, status: "Selesai" },
];

export function Pengaturan() {
  return (
    <div className="min-h-screen bg-[#f5f7f2] font-sans text-[#17352d]">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-600 text-white shadow-lg">
        <div className="max-w-3xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center font-extrabold text-sm">B</div>
            <div>
              <div className="font-bold text-lg leading-tight">BLP Harian</div>
              <div className="text-xs text-emerald-100">SMP TISA Islamic School</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm font-semibold">Aisyah Rahmawati</div>
              <div className="text-xs text-emerald-100">Kelas 7A</div>
            </div>
            <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center font-bold text-sm">AR</div>
            <button className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg text-sm">
              <LogOut className="w-4 h-4" /> Keluar
            </button>
          </div>
        </div>
        <div className="max-w-3xl mx-auto px-6 flex gap-1 pb-0">
          {[
            { label: "Harian", icon: LayoutDashboard }, { label: "Kalender", icon: Calendar },
            { label: "Pengaturan", icon: Settings, active: true },
          ].map(tab => (
            <button key={tab.label} className={`flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-t-xl transition ${tab.active ? "bg-[#f5f7f2] text-emerald-700 shadow-sm" : "text-white/80 hover:bg-white/10"}`}>
              <tab.icon className="w-4 h-4" /> {tab.label}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-8 space-y-5">
        {/* Profile card */}
        <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm p-6">
          <h3 className="font-bold text-[#17352d] mb-4 flex items-center gap-2"><User className="w-5 h-5 text-emerald-600" /> Profil Saya</h3>
          <div className="flex items-center gap-5">
            <div className="relative">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-white text-2xl font-black">AR</div>
              <button className="absolute -bottom-1 -right-1 w-7 h-7 bg-emerald-600 rounded-full flex items-center justify-center text-white shadow-lg">
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="flex-1">
              <div className="font-bold text-lg text-[#17352d]">Aisyah Rahmawati</div>
              <div className="text-sm text-gray-500">Kelas 7A · @aisyah.r</div>
              <div className="mt-2 text-sm text-gray-600 bg-gray-50 rounded-xl px-3 py-2 italic">"Semangat belajar setiap hari untuk menjadi lebih baik 🌱"</div>
            </div>
          </div>
          <button className="mt-4 w-full border border-emerald-200 text-emerald-700 hover:bg-emerald-50 rounded-xl py-2.5 text-sm font-semibold transition">
            Edit Profil & Foto
          </button>
        </div>

        {/* Notifications toggle */}
        <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm p-6">
          <h3 className="font-bold text-[#17352d] mb-4 flex items-center gap-2"><Bell className="w-5 h-5 text-emerald-600" /> Pengingat</h3>
          <div className="flex items-center justify-between">
            <div>
              <div className="font-semibold text-sm text-[#17352d]">Notifikasi pengingat harian</div>
              <div className="text-xs text-gray-500 mt-0.5">Ingatkan untuk mengisi BLP setiap hari</div>
            </div>
            {/* Toggle ON */}
            <button className="w-14 h-7 bg-emerald-500 rounded-full relative flex items-center px-0.5">
              <div className="w-6 h-6 bg-white rounded-full shadow-md ml-auto" />
            </button>
          </div>
        </div>

        {/* Data export */}
        <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm p-6">
          <h3 className="font-bold text-[#17352d] mb-2 flex items-center gap-2"><Download className="w-5 h-5 text-emerald-600" /> Ekspor Data</h3>
          <p className="text-sm text-gray-500 mb-4">Unduh seluruh data BLP Anda dalam format JSON</p>
          <button className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold shadow transition">
            <Download className="w-4 h-4" /> Ekspor Data JSON
          </button>
        </div>

        {/* Haid tracking */}
        <div className="bg-white rounded-2xl border border-rose-100 shadow-sm p-6">
          <h3 className="font-bold text-[#17352d] mb-1 flex items-center gap-2"><Heart className="w-5 h-5 text-rose-500" /> Catatan Haid</h3>
          <p className="text-xs text-gray-500 mb-5">Fitur ini membantu mencatat periode haid untuk penyesuaian aktivitas</p>

          {/* Current status */}
          <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 mb-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-bold text-rose-700 flex items-center gap-1.5"><Heart className="w-4 h-4" /> Tidak Sedang Haid</div>
                <div className="text-xs text-rose-500 mt-0.5">Siklus terakhir: 5–11 Jun 2026 (7 hari)</div>
              </div>
              <button className="bg-rose-500 hover:bg-rose-600 text-white px-4 py-2 rounded-xl text-xs font-bold transition">
                Mulai Periode
              </button>
            </div>
          </div>

          {/* History */}
          <div className="text-sm font-semibold text-gray-700 mb-3">Riwayat 6 Periode Terakhir</div>
          <div className="space-y-2">
            {haidHistory.map((h, i) => (
              <div key={i} className="flex items-center justify-between py-2.5 px-3 bg-gray-50 rounded-xl text-sm">
                <div className="flex items-center gap-2 text-gray-600">
                  <Clock className="w-3.5 h-3.5 text-rose-400" />
                  <span>{h.start} – {h.end}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-gray-500 text-xs">{h.duration} hari</span>
                  <span className="bg-rose-100 text-rose-700 text-xs px-2 py-0.5 rounded-full font-medium">{h.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Logout */}
        <button className="w-full flex items-center justify-center gap-2 bg-white border border-red-200 text-red-600 hover:bg-red-50 rounded-2xl py-3.5 text-sm font-semibold transition shadow-sm">
          <LogOut className="w-4 h-4" /> Keluar dari Akun
        </button>
      </main>
    </div>
  );
}
