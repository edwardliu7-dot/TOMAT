import {
  ChevronLeft, ChevronRight, Download, FileSpreadsheet, BarChart2,
  Calendar, Settings, LayoutDashboard, LogOut, Bell
} from "lucide-react";

const daysInMonth = 31;
const today = 1;

const dayData: Record<number, { pct: number; filled: boolean }> = {
  1: { pct: 95, filled: true }, 2: { pct: 80, filled: true }, 3: { pct: 100, filled: true },
  4: { pct: 60, filled: true }, 5: { pct: 75, filled: true }, 6: { pct: 88, filled: true },
  7: { pct: 0, filled: false }, 8: { pct: 92, filled: true }, 9: { pct: 70, filled: true },
  10: { pct: 85, filled: true }, 11: { pct: 55, filled: true }, 12: { pct: 90, filled: true },
  13: { pct: 78, filled: true }, 14: { pct: 0, filled: false }, 15: { pct: 82, filled: true },
  16: { pct: 94, filled: true }, 17: { pct: 71, filled: true }, 18: { pct: 88, filled: true },
  19: { pct: 65, filled: true }, 20: { pct: 79, filled: true }, 21: { pct: 0, filled: false },
  22: { pct: 91, filled: true }, 23: { pct: 84, filled: true }, 24: { pct: 96, filled: true },
  25: { pct: 73, filled: true }, 26: { pct: 87, filled: true }, 27: { pct: 68, filled: true },
  28: { pct: 0, filled: false }, 29: { pct: 93, filled: true }, 30: { pct: 76, filled: true },
  31: { pct: 89, filled: true },
};

const catData = [
  { label: "Ketaqwaan",  pct: 88, color: "bg-emerald-500" },
  { label: "Ketangguhan", pct: 73, color: "bg-amber-500" },
  { label: "Kecakapan",  pct: 81, color: "bg-blue-500" },
  { label: "Reflektif",  pct: 68, color: "bg-violet-500" },
  { label: "Kepedulian", pct: 77, color: "bg-rose-500" },
];

function dayColor(pct: number, filled: boolean) {
  if (!filled) return "bg-gray-100 text-gray-400";
  if (pct >= 90) return "bg-emerald-500 text-white";
  if (pct >= 75) return "bg-emerald-300 text-emerald-900";
  if (pct >= 60) return "bg-amber-300 text-amber-900";
  return "bg-red-200 text-red-800";
}

export function Kalender() {
  const firstDayOfWeek = 2; // Tuesday (Aug 1 2026)
  const blanks = firstDayOfWeek;
  const cells = [...Array(blanks).fill(null), ...Array(daysInMonth).fill(0).map((_, i) => i + 1)];
  const rows: (number | null)[][] = [];
  for (let i = 0; i < cells.length; i += 7) rows.push(cells.slice(i, i + 7));

  return (
    <div className="min-h-screen bg-[#f5f7f2] font-sans text-[#17352d]">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-600 text-white shadow-lg">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center font-extrabold text-sm">B</div>
            <div>
              <div className="font-bold text-lg leading-tight">BLP Harian</div>
              <div className="text-xs text-emerald-100">SMP TISA Islamic School</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm font-semibold">Aisyah Rahmawati</div>
              <div className="text-xs text-emerald-100">Kelas 7A</div>
            </div>
            <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center font-bold text-sm">AR</div>
            <button className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg text-sm">
              <LogOut className="w-4 h-4" /> Keluar
            </button>
          </div>
        </div>
        {/* Tabs */}
        <div className="max-w-5xl mx-auto px-6 flex gap-1 pb-0">
          {[
            { label: "Harian", icon: LayoutDashboard }, { label: "Kalender", icon: Calendar, active: true },
            { label: "Pengaturan", icon: Settings },
          ].map(tab => (
            <button key={tab.label} className={`flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-t-xl transition ${tab.active ? "bg-[#f5f7f2] text-emerald-700 shadow-sm" : "text-white/80 hover:bg-white/10"}`}>
              <tab.icon className="w-4 h-4" /> {tab.label}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8 space-y-6">
        {/* Month nav + stats */}
        <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <button className="w-9 h-9 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700 hover:bg-emerald-100">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="text-center">
              <h2 className="text-xl font-bold text-[#17352d]">Agustus 2026</h2>
              <p className="text-sm text-gray-500">Kelas 7A · 27 hari aktif dari 31</p>
            </div>
            <button className="w-9 h-9 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700 hover:bg-emerald-100">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            {[
              { label: "Rata-rata", val: "82%", sub: "bulan ini", color: "text-emerald-600" },
              { label: "Hari Aktif", val: "27", sub: "dari 31 hari", color: "text-blue-600" },
              { label: "Terbaik", val: "100%", sub: "3 Agustus", color: "text-amber-600" },
            ].map(s => (
              <div key={s.label} className="bg-gray-50 rounded-xl p-4 text-center">
                <div className={`text-2xl font-black ${s.color}`}>{s.val}</div>
                <div className="text-xs font-semibold text-gray-700 mt-0.5">{s.label}</div>
                <div className="text-[11px] text-gray-400">{s.sub}</div>
              </div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-1.5 mb-2">
            {["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"].map(d => (
              <div key={d} className="text-center text-[11px] font-bold text-gray-400 py-1">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {rows.flat().map((day, i) => {
              if (!day) return <div key={`blank-${i}`} />;
              const d = dayData[day];
              const isWeekend = (i + blanks) % 7 >= 5;
              return (
                <button
                  key={day}
                  className={`aspect-square rounded-xl flex flex-col items-center justify-center text-sm font-bold transition hover:scale-105 ${isWeekend ? "bg-gray-100 text-gray-400" : dayColor(d?.pct ?? 0, d?.filled ?? false)}`}
                >
                  <span>{day}</span>
                  {d?.filled && !isWeekend && <span className="text-[9px] font-semibold opacity-80">{d.pct}%</span>}
                </button>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex items-center gap-4 mt-4 text-[11px] text-gray-500">
            {[["bg-emerald-500","≥90%"],["bg-emerald-300","75–89%"],["bg-amber-300","60–74%"],["bg-red-200","<60%"],["bg-gray-100","Libur/Kosong"]].map(([c,l]) => (
              <div key={l} className="flex items-center gap-1.5">
                <div className={`w-3 h-3 rounded-sm ${c}`} />
                <span>{l}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Category analysis */}
        <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm p-6">
          <h3 className="font-bold text-[#17352d] mb-4">Analisis per Kategori BLP</h3>
          <div className="space-y-3">
            {catData.map(c => (
              <div key={c.label}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium text-gray-700">{c.label}</span>
                  <span className="font-bold text-gray-800">{c.pct}%</span>
                </div>
                <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className={`h-full ${c.color} rounded-full`} style={{ width: `${c.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Export */}
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold shadow transition">
            <Download className="w-4 h-4" /> Unduh PDF
          </button>
          <button className="flex items-center gap-2 bg-white hover:bg-gray-50 text-emerald-700 border border-emerald-200 px-5 py-2.5 rounded-xl text-sm font-semibold shadow-sm transition">
            <FileSpreadsheet className="w-4 h-4" /> Unduh Excel
          </button>
        </div>
      </main>
    </div>
  );
}
